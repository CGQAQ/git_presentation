# 作业四 **回到reset之前**

> 在workspace目录下用命令行新建 Git 仓库，创建main分支提交两次后
> reset回去一次，请问如何回到reset之前

## 考点
1. 自由移动分支
2. 查看历史操作记录
