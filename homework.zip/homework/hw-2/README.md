# 作业二 **解决提交到了错误的分支的问题**

> 假设*workspace*是从其他地方*clone*过来的项目代码，项目规定，
> main分支不允许提交，你发现hello.txt中hello world的world写出了
> worrld，于是你就修改好后commit了一下，这时你才发现你commit到了
> main分支下，于是你赶紧新建了个*fix_world*分支，请问你该如何在
> 不编辑hello.txt文件的情况下把提交到main上的commit“移动”到
> *fix_world*分支上，并使main分支
> 恢复原样（恢复到内容为`hello worrld`的状态）

## 考点
1. 如何切换分支
2. 如何把其他分支上的commit应用到当前分支
3. 如何将分支恢复到原来的状态
